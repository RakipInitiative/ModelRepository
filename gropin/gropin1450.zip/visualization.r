############################# 
# start of Visualisation script Gropin ID 1450 
#############################
plot(T,responseSurface$'mumax',xlab='T',
                          ylab='mumax',main='Response surface mumax for
Salmonella Typhimurium in/on Chicken _cooked_
(gropin ID:1450)')
#############################
# End of Visualisation script
#############################
